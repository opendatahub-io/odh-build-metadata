MaaS e2e diagnostics (ai-gateway-controller)

This directory complements gather-openshift/ from oc adm must-gather.
OpenShift must-gather does not collect maas.opendatahub.io CRs or tenant
readiness details needed for default-tenant / AITenant flake debugging.

Key files for tenant-not-ready / webhook / routing failures:
  summaries/dsc-status.txt
  crs/dsc/datasciencecluster-default-dsc.yaml
  crs/dsc/datascienceclusters-all.yaml
  crs/dsc/dscinitializations-all.yaml
  crs/maastenantconfig-default-tenant.yaml
  crs/aitenant-models-as-a-service.yaml
  crs/config-default.yaml
  summaries/tenant-readiness.txt
  summaries/maas-resources-wide.txt
  gateway-api/httproutes-wide.txt
  gateway-api/httproutes-cluster-all.yaml
  gateway-api/httproute-maas-api-route.yaml
  gateway-api/httproutes-<ns>.yaml (gateway, subscription, infra, llm, ai-tenant-*, e2e-*)
  gateway-api/gateway-maas-default-gateway.yaml
  crs/maas/*-all.yaml (every maas.opendatahub.io kind)
  crs/inference/*-all.yaml (inference.opendatahub.io ExternalModel/Provider)
  logs/maas-controller-tenant.log
  workloads/payload-processing-openshift-ingress.yaml
  namespaces/events-models-as-a-service.txt
  namespaces/events-ai-tenants.txt
